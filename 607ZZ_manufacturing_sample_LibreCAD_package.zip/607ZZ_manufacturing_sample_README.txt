607ZZ BEARING - MANUFACTURING-STYLE CAD SAMPLE
=============================================
Purpose: educational/reference engineering drawing based on SMB Bearings 607ZZ product datasheet.
Status: NOT FOR MANUFACTURE / NOT APPROVED.

FILES
- 607ZZ_manufacturing_sample_A3_assembly_and_details.pdf : printable two-page A3 drawing.
- 607ZZ_manufacturing_sample_sheet1_assembly_LibreCAD.dxf : editable engineering sheet #1.
- 607ZZ_manufacturing_sample_sheet2_components_LibreCAD.dxf : editable engineering sheet #2.
- 607ZZ_manufacturing_sample_true_size_geometry.dxf : nominal 1:1 bearing geometry in millimetres.
- 607ZZ_manufacturing_sample_sheet1_preview.png : sheet 1 raster preview.
- 607ZZ_manufacturing_sample_sheet2_preview.png : sheet 2 raster preview.

HOW TO OPEN
LibreCAD > File > Open > choose a DXF > View > Auto Zoom.
All files use millimetres. Sheet DXFs contain enlarged views laid out on A3 paper.
Do NOT measure sheet views to determine actual bearing dimensions; read callout values.
For nominal 1:1 CAD measurements use the separate true_size_geometry.dxf.

SOURCE-BASED DIMENSIONS / PROPERTIES
OD = 19 mm, P0 deviation +0/-0.009 mm.
Bore = 7 mm, P0 deviation +0/-0.008 mm.
Width = 6 mm, P0 deviation +0/-0.120 mm.
Corner detail = 0.3 mm minimum per supplier sketch.
Materials: SAE52100 steel (rings and balls), pressed steel cage, metal shields.
P0 is selected for illustration from the supplier's alternative tolerance classes.
Radial play class for the actual bearing has NOT been selected.

UNVERIFIED INTERNAL DESIGN (DEMONSTRATION ASSUMPTIONS)
Seven 3 mm balls on 13 mm pitch diameter, inner ring land/groove and outer ring land/groove
illustrated in drawing. These details are NOT from the supplier document, nor certified
for function or manufacturing. The ring cross-sections on Sheet 2 are schematic (NTS).

RELEASE DATA NEEDED BEFORE MANUFACTURE
Manufacturer-approved raceway form and grooves; ball grade, count and diameter;
cage die shape/stock thickness/clearances; shield retention, fit and geometry;
material heat treatment/hardness; surface finish; radial play selection;
full tolerance and geometrical inspection requirements; validated production process.

Do not machine or inspect production components from these demonstration files.
